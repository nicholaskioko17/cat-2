<?php
      // Database connection constants
define('db_host', 'localhost');
define('username', 'root');
define('password', "");
define('dbname', 'authorsdb');
?>