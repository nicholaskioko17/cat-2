<?php
require_once '../configs/Dbconn.php'; 
require_once '../processes/viewauthors.php';

if (isset($_GET['authorId'])) {
    $authorId = $_GET['authorId'];

    
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
        // Delete the author from the database
        $stmt = $DBconn->prepare("DELETE FROM authortb WHERE authorId = :authorId");
        $stmt->bindParam(':authorId', $authorId);

        try {
            $stmt->execute();
            echo "Author successfully deleted.";
            exit();
        } catch (PDOException $e) {
            echo "Error deleting author: " . $e->getMessage();
        }
    }
} else {
    echo "Author ID not provided.";
    exit();
}


$stmt = $DBconn->prepare("SELECT * FROM authorstb WHERE authorId= :authorId");
$stmt->bindParam(':authorId', $authorId);
$stmt->execute();
$author = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$author) {
    echo "Author not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Author</title>
</head>
<body>
    <h2>Delete Author</h2>
    <p>Are you sure you want to delete the author with Full Names: <?= $author['full_names']; ?>?</p>
    
    <form method="post" action="">
        <input type="submit" name="delete" value="Delete">
        <a href="view.php">Cancel</a>
    </form>
</body>
</html>
