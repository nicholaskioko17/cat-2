<?php

require_once '../configs/Dbconn.php'; 


$stmt = $DBconn->prepare("SELECT * FROM authorstb ORDER BY authorFullNames ASC");
$stmt->execute();
$authors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Authors</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">


    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            font-family: 'Times New Roman', Times, serif;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }body{
            background-color: cadetblue;
        }

        th {
            background-color: grey;
        }
        

    </style>
</head>
<body>
    <h2>Registered Authors</h2>
<table class="table table-striped table-hover">

        <thead>
            <tr>
                <th>Author ID</th>
                <th>Email</th>
                <th>Address</th>
                <th>Full Names</th>
                <th>Biography</th>
                <th>Date of Birth</th>
                <th>Suspension</th>

                
            </tr>
        </thead>
        <tbody>
            <?php foreach ($authors as $author): ?>
                <tr>
                    <td>[<a href="editAuth.php?EditId=<?php print $author["authorId"];?>">Edit</a> ]<?= $author['authorId']; ?>
                    <br><br>[<a href="DelAuth.php?DelId=<?php print $author["authorId"];?>" OnClick="return confirm('Are you sure you want to delete this author from the database?');">Del</a> ]</td>
                    <td><?= $author['authorEmail']; ?></td>
                    <td><?= $author['authorAddress']; ?></td>
                    <td><?= $author['authorFullNames']; ?></td>
                    <td><?= $author['authorBiography']; ?></td>
                    <td><?= $author['authorDateOfBirth']; ?></td>
                    <td><?= $author['authorSuspended']; ?></td>
                    
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
