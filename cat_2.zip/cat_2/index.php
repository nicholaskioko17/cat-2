<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - DBT</title>
    <link rel="stylesheet" href="css/style.css" >
</head>
<body>
    <!-- top navigation starts here -->
    <?php require "includes/navigation.php"; ?>
    <!-- top navigation ends here -->
<div class="header">
    <h1>Registration</h1>
</div>
<!-- the main content section starts here -->
<div class="row">
    <div class="content">
    <h2>Author Registration</h2>
    <form action="processes/AutRegistration.php" method="POST" >
        <label for="Author id">Author id:</label><br>
        <input type="text" name="author_id" id="author_id" placeholder="Enter Author id" maxlength="60" required /><br><br>


        
        <label>Full Names:</label>
        <input type="text" name="authorFullNames"  placeholder="Enter Full Names"required><br>

        <label>Author Email:</label>
        <input type="email" name="authorEmail" id=authorEmail  placeholder="Enter Author Email"required><br>

        <label>Author Address:</label>
        <input type="text" name="AuthorAddress"  id=authorAddress  placeholder="Enter Author Address"  required><br>

        <label>Author Biography:</label>
        <textarea name="AuthorBiography" id="authorBiography" rows="4"   placeholder="Enter Author Biography" required></textarea><br>

        <label>Author Date of Birth:</label>
        <input type="date" name="DateOfBirth" id="authorDateOfBirth"  placeholder="Enter Author Biography" required><br>

        <label>Suspend Account:</label>
        <input type="checkbox" name="authorSuspended"><br>

        <input type="submit" value="Register">
    </form>
</body>
<div class="footer">
copyright &copy; Kioko 2023
</div>
</body>
</html>
</html>
