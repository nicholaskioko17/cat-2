<?php
require_once "../configs/Dbconn.php";

$servername = "localhost";
$db_username = "root"; 
$db_password = ""; 
$database = "authorsdb";

$conn = new mysqli($servername, $db_username, $db_password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $authorId=$_POST["author_id"];
    $AuthorFullName = $_POST["authorFullNames"];
    $AuthorEmail=$_POST["authorEmail"];
    $AuthorAddress = $_POST["AuthorAddress"];
    $AuthorBiography = $_POST["AuthorBiography"];
    $AuthorDateOfBirth = $_POST["DateOfBirth"];
    $AuthorSuspended = $_POST["authorSuspended"];

    $sql = "INSERT INTO authorstb (authorId, authorFullNames, authorEmail, authorAddress , authorBiography, authorDateOfBirth, authorSuspended ) VALUES ('$authorId', '$AuthorFullName', '$AuthorEmail', '$AuthorAddress','$AuthorBiography','$AuthorDateOfBirth','$AuthorSuspended')";
    if ($conn->query($sql) === true) {
        echo "Signup successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

   
